import boto3
import os

rds = boto3.client("rds-data")

def lambda_handler(event, context):
    result = rds.execute_statement(
        resourceArn=os.environ["CLUSTER_ARN"],
        secretArn=os.environ["SECRET_ARN"],
        database=os.environ["DATABASE_NAME"],
        sql="SELECT 1 AS connection_test"
    )

    return {
        "statusCode": 200,
        "result": result["records"][0][0]["longValue"]
    }
